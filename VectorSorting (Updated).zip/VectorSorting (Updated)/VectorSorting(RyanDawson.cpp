//============================================================================
// Name        : VectorSorting.cpp
// Author      : Ryan Dawson
// Version     : 2.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Hybrid Vector Sorting Algorithms
//============================================================================

#include <algorithm>
#include <iostream>
#include <time.h>
#include <vector>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Hybrid sort threshold
const int INSERTION_SORT_THRESHOLD = 10;

// Comparison counter for algorithm analysis
long long comparisonCount = 0;

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId;
    string title;
    string fund;
    double amount;

    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Utility Functions
//============================================================================

/**
 * Display the bid information
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": "
        << bid.title << " | "
        << bid.amount << " | "
        << bid.fund << endl;
}

/**
 * Prompt user for bid information
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();

    string strAmount;
    getline(cin, strAmount);

    bid.amount = strToDouble(strAmount, '$');

    return bid;
}

/**
 * Load bids from CSV file
 */
vector<Bid> loadBids(string csvPath) {

    cout << "Loading CSV file " << csvPath << endl;

    vector<Bid> bids;

    csv::Parser file = csv::Parser(csvPath);

    try {

        for (int i = 0; i < file.rowCount(); i++) {

            Bid bid;

            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            bids.push_back(bid);
        }
    }
    catch (csv::Error& e) {
        cerr << e.what() << endl;
    }

    return bids;
}

//============================================================================
// Sorting Algorithms
//============================================================================

/**
 * Insertion sort for small partitions
 */
void insertionSort(vector<Bid>& bids, int begin, int end) {

    for (int i = begin + 1; i <= end; i++) {

        Bid key = bids[i];
        int j = i - 1;

        while (j >= begin) {

            comparisonCount++;

            if (bids[j].title <= key.title) {
                break;
            }

            bids[j + 1] = bids[j];
            j--;
        }

        bids[j + 1] = key;
    }
}

/**
 * Partition vector using Hoare partition scheme
 */
int partition(vector<Bid>& bids, int begin, int end) {

    int low = begin;
    int high = end;

    int middle = begin + (end - begin) / 2;

    const string& pivot = bids[middle].title;

    while (true) {

        while (bids[low].title < pivot) {
            comparisonCount++;
            low++;
        }

        comparisonCount++;

        while (pivot < bids[high].title) {
            comparisonCount++;
            high--;
        }

        comparisonCount++;

        if (low >= high) {
            return high;
        }

        swap(bids[low], bids[high]);

        low++;
        high--;
    }
}

/**
 * Hybrid Quick Sort
 * Uses insertion sort on small partitions
 */
void quickSort(vector<Bid>& bids, int begin, int end) {

    if (begin >= end) {
        return;
    }

    // Switch to insertion sort for small partitions
    if ((end - begin + 1) <= INSERTION_SORT_THRESHOLD) {
        insertionSort(bids, begin, end);
        return;
    }

    int pivotIndex = partition(bids, begin, end);

    quickSort(bids, begin, pivotIndex);
    quickSort(bids, pivotIndex + 1, end);
}

/**
 * Selection Sort
 */
void selectionSort(vector<Bid>& bids) {

    size_t size = bids.size();

    for (size_t pos = 0; pos < size - 1; ++pos) {

        size_t min = pos;

        for (size_t j = pos + 1; j < size; ++j) {

            comparisonCount++;

            if (bids[j].title < bids[min].title) {
                min = j;
            }
        }

        if (min != pos) {
            swap(bids[pos], bids[min]);
        }
    }
}

//============================================================================
// Helper Functions
//============================================================================

/**
 * Convert string to double after removing unwanted character
 */
double strToDouble(string str, char ch) {

    str.erase(remove(str.begin(), str.end(), ch), str.end());

    return atof(str.c_str());
}

//============================================================================
// Main Program
//============================================================================

int main(int argc, char* argv[]) {

    string csvPath;

    switch (argc) {

    case 2:
        csvPath = argv[1];
        break;

    default:
        csvPath = "eBid_Monthly_Sales.csv";
    }

    vector<Bid> bids;

    clock_t ticks;

    int choice = 0;

    while (choice != 9) {

        cout << endl;
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Hybrid Quick Sort All Bids" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";

        cin >> choice;

        switch (choice) {

        case 1:

            ticks = clock();

            bids = loadBids(csvPath);

            cout << bids.size() << " bids read" << endl;

            ticks = clock() - ticks;

            cout << "time: "
                << ticks
                << " clock ticks"
                << endl;

            cout << "time: "
                << ticks * 1.0 / CLOCKS_PER_SEC
                << " seconds"
                << endl;

            break;

        case 2:

            for (unsigned int i = 0; i < bids.size(); ++i) {
                displayBid(bids[i]);
            }

            cout << endl;

            break;

        case 3:

            comparisonCount = 0;

            ticks = clock();

            selectionSort(bids);

            ticks = clock() - ticks;

            cout << bids.size() << " bids sorted" << endl;
            cout << "Selection Sort completed" << endl;
            cout << "Comparisons: " << comparisonCount << endl;

            cout << "time: "
                << ticks
                << " clock ticks"
                << endl;

            cout << "time: "
                << ticks * 1.0 / CLOCKS_PER_SEC
                << " seconds"
                << endl;

            break;

        case 4:

            comparisonCount = 0;

            ticks = clock();

            if (!bids.empty()) {
                quickSort(bids, 0, bids.size() - 1);
            }

            ticks = clock() - ticks;

            cout << bids.size() << " bids sorted" << endl;
            cout << "Hybrid Quick Sort completed" << endl;
            cout << "Comparisons: " << comparisonCount << endl;

            cout << "time: "
                << ticks
                << " clock ticks"
                << endl;

            cout << "time: "
                << ticks * 1.0 / CLOCKS_PER_SEC
                << " seconds"
                << endl;

            break;

        case 9:

            cout << "Good bye." << endl;

            break;

        default:

            cout << "Invalid selection." << endl;
        }
    }

    return 0;
}