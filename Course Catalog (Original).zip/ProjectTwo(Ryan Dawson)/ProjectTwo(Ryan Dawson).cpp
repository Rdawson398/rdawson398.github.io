//============================================================================
// Name        : Project Two(RyanDawson).cpp
// Author      : Ryan Dawson
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Project Two
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <sqlite3.h>
#include <unordered_set>

using namespace std;

// Structure to hold course information
struct Course {
    string courseId;
    string title;
    vector<string> prerequisites;
};

// Class to manage course data
class CourseCatalog {
private:
    unordered_map<string, Course> courses;

public:
    void LoadCourses(const string& filename);
    void PrintAllCourses();
    void PrintCourseInfo(const string& courseId);
};

void CourseCatalog::LoadCourses(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseId, title, prereq;
        getline(ss, courseId, ',');
        getline(ss, title, ',');
        Course course{ courseId, title, {} };
        while (getline(ss, prereq, ',')) {
            course.prerequisites.push_back(prereq);
        }
        courses[courseId] = course;
    }
    file.close();
    cout << "Courses loaded successfully!" << endl;
}

void CourseCatalog::PrintAllCourses() {
    vector<Course> sortedCourses;
    for (const auto& pair : courses) {
        sortedCourses.push_back(pair.second);
    }

    sort(sortedCourses.begin(), sortedCourses.end(),
        [](const Course& a, const Course& b) {
            return a.courseId < b.courseId;
        });

    cout << "\nCourse List:" << endl;
    for (const auto& course : sortedCourses) {
        cout << course.courseId << ": " << course.title << endl;
    }
}

void CourseCatalog::PrintCourseInfo(const string& courseId) {
    if (courses.find(courseId) != courses.end()) {
        Course course = courses[courseId];

        cout << "\nCourse: "
            << course.courseId
            << " - "
            << course.title
            << endl;

        cout << "Prerequisites: ";

        if (course.prerequisites.empty()) {
            cout << "None";
        }
        else {
            for (const auto& prereq : course.prerequisites) {
                cout << prereq << " ";
            }
        }

        cout << endl;
    }
    else {
        cout << "Course not found." << endl;
    }
}

int main() {
    CourseCatalog catalog;

    string filename = "CS 300 ABCU_Advising_Program_Input.csv";

    int choice;
    string courseId;

    while (true) {

        cout << "\nMenu:" << endl;
        cout << "1. Load Course Data" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course Information" << endl;
        cout << "9. Exit" << endl;
        cout << "Enter choice: ";

        cin >> choice;

        switch (choice) {

        case 1:
            catalog.LoadCourses(filename);
            break;

        case 2:
            catalog.PrintAllCourses();
            break;

        case 3:
            cout << "Enter course ID: ";
            cin >> courseId;
            catalog.PrintCourseInfo(courseId);
            break;

        case 9:
            cout << "Exiting program. Goodbye!" << endl;
            return 0;

        default:
            cout << "Invalid choice. Try again." << endl;
        }
    }
}
