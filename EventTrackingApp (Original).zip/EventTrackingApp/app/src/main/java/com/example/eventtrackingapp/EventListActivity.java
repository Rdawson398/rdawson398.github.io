package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class EventListActivity extends AppCompatActivity {

    private RecyclerView eventRecycler;
    private ImageButton addEventButton, smsPermissionButton;

    private DatabaseHelper dbHelper;
    private EventRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        dbHelper = new DatabaseHelper(this);

        // Bind UI elements
        eventRecycler = findViewById(R.id.eventRecycler);
        addEventButton = findViewById(R.id.addEventButton);
        smsPermissionButton = findViewById(R.id.smsPermissionButton);

        // Setup RecyclerView
        eventRecycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventRecyclerAdapter(this, dbHelper.getAllEvents(), dbHelper);
        eventRecycler.setAdapter(adapter);

        // Button to add a new event
        addEventButton.setOnClickListener(v -> startActivity(new Intent(EventListActivity.this, AddEventActivity.class)));


    }
}
