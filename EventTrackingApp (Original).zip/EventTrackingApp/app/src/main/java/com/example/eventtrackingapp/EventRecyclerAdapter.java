package com.example.eventtrackingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.EventViewHolder> {

    private Context context;
    private List<Event> eventList;
    private DatabaseHelper dbHelper;

    public EventRecyclerAdapter(Context context, List<Event> eventList, DatabaseHelper dbHelper) {
        this.context = context;
        this.eventList = eventList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.event_row, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        holder.textTitle.setText(event.getTitle());
        holder.textDate.setText(event.getDate());
        holder.textTime.setText(event.getTime());

        holder.deleteButton.setOnClickListener(v -> {
            boolean deleted = dbHelper.deleteEvent(event.getId());
            if (deleted) {
                Toast.makeText(context, "Event deleted", Toast.LENGTH_SHORT).show();
                eventList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, eventList.size());
            } else {
                Toast.makeText(context, "Failed to delete event", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle, textDate, textTime;
        ImageButton deleteButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDate = itemView.findViewById(R.id.textDate);
            textTime = itemView.findViewById(R.id.textTime);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
