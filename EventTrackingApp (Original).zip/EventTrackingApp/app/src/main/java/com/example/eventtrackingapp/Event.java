package com.example.eventtrackingapp;

public class Event {
    private int id;
    private String title;
    private String date;
    private String time;

    public Event(int id, String title, String date, String time) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.time = time;
    }

    // Getters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDate() { return date; }
    public String getTime() { return time; }
}
