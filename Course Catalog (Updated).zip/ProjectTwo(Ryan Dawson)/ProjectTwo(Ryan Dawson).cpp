//============================================================================
// Name        : Project Two (Ryan Dawson)
// Version     : 2.0 FINAL
// Description : Enhanced Course Advising System with SQLite Database
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <string>
#include <limits>

#include "sqlite3.h"

using namespace std;

//============================================================================
// Course Structure
//============================================================================

struct Course {
    string courseId;
    string title;
    vector<string> prerequisites;
};

//============================================================================
// Course Catalog Class
//============================================================================

class CourseCatalog {
private:
    unordered_map<string, Course> courses;
    sqlite3* db;

    bool DetectCycle(
        const string& courseId,
        unordered_set<string>& visited,
        unordered_set<string>& recursionStack);

    void DisplayPathRecursive(
        const string& courseId,
        int depth);

public:
    CourseCatalog();
    ~CourseCatalog();

    bool OpenDatabase();
    void CreateTables();

    void LoadCourses(const string& filename);

    void SaveCoursesToDatabase();
    void LoadCoursesFromDatabase();

    void AddCourse();
    void UpdateCourse();
    void DeleteCourse();

    void PrintAllCourses();
    void PrintCourseInfo(const string& courseId);

    bool ValidatePrerequisites();
    void DisplayCoursePath(const string& courseId);
};

//============================================================================
// Constructor / Destructor
//============================================================================

CourseCatalog::CourseCatalog() {
    db = nullptr;

    if (OpenDatabase()) {
        CreateTables();
    }
}

CourseCatalog::~CourseCatalog() {
    if (db != nullptr) {
        sqlite3_close(db);
    }
}

//============================================================================
// Database Setup
//============================================================================

bool CourseCatalog::OpenDatabase() {
    int rc = sqlite3_open("courses.db", &db);

    if (rc != SQLITE_OK) {
        cerr << "Failed to open database." << endl;
        return false;
    }

    cout << "Database connected successfully." << endl;
    return true;
}

void CourseCatalog::CreateTables() {

    const char* coursesSQL =
        "CREATE TABLE IF NOT EXISTS Courses ("
        "courseId TEXT PRIMARY KEY,"
        "title TEXT NOT NULL"
        ");";

    const char* prereqSQL =
        "CREATE TABLE IF NOT EXISTS Prerequisites ("
        "courseId TEXT,"
        "prerequisiteId TEXT,"
        "PRIMARY KEY(courseId, prerequisiteId)"
        ");";

    char* errMsg = nullptr;

    sqlite3_exec(db, coursesSQL, nullptr, nullptr, &errMsg);
    sqlite3_exec(db, prereqSQL, nullptr, nullptr, &errMsg);

    cout << "Database tables ready." << endl;
}

//============================================================================
// Load from CSV
//============================================================================

void CourseCatalog::LoadCourses(const string& filename) {

    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    courses.clear();

    string line;

    while (getline(file, line)) {

        stringstream ss(line);

        Course course;

        getline(ss, course.courseId, ',');
        getline(ss, course.title, ',');

        string prereq;

        while (getline(ss, prereq, ',')) {
            if (!prereq.empty()) {
                course.prerequisites.push_back(prereq);
            }
        }

        courses[course.courseId] = course;
    }

    file.close();

    cout << courses.size()
        << " courses loaded from CSV." << endl;
}

//============================================================================
// Save to Database
//============================================================================

void CourseCatalog::SaveCoursesToDatabase() {

    sqlite3_exec(db, "DELETE FROM Prerequisites;", nullptr, nullptr, nullptr);
    sqlite3_exec(db, "DELETE FROM Courses;", nullptr, nullptr, nullptr);

    for (const auto& pair : courses) {

        const Course& course = pair.second;

        string courseSQL =
            "INSERT INTO Courses(courseId, title) VALUES('"
            + course.courseId + "','"
            + course.title + "');";

        sqlite3_exec(db, courseSQL.c_str(), nullptr, nullptr, nullptr);

        for (const string& prereq : course.prerequisites) {

            string prereqSQL =
                "INSERT INTO Prerequisites(courseId, prerequisiteId) VALUES('"
                + course.courseId + "','"
                + prereq + "');";

            sqlite3_exec(db, prereqSQL.c_str(), nullptr, nullptr, nullptr);
        }
    }

    cout << "Courses saved to database." << endl;
}

//============================================================================
// Load from Database
//============================================================================

void CourseCatalog::LoadCoursesFromDatabase() {

    courses.clear();

    sqlite3_stmt* stmt;

    const char* sql = "SELECT courseId, title FROM Courses;";

    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);

    while (sqlite3_step(stmt) == SQLITE_ROW) {

        Course course;

        course.courseId =
            (const char*)sqlite3_column_text(stmt, 0);

        course.title =
            (const char*)sqlite3_column_text(stmt, 1);

        courses[course.courseId] = course;
    }

    sqlite3_finalize(stmt);

    const char* prereqSQL =
        "SELECT courseId, prerequisiteId FROM Prerequisites;";

    sqlite3_prepare_v2(db, prereqSQL, -1, &stmt, nullptr);

    while (sqlite3_step(stmt) == SQLITE_ROW) {

        string courseId =
            (const char*)sqlite3_column_text(stmt, 0);

        string prereq =
            (const char*)sqlite3_column_text(stmt, 1);

        if (courses.find(courseId) != courses.end()) {
            courses[courseId].prerequisites.push_back(prereq);
        }
    }

    sqlite3_finalize(stmt);

    cout << courses.size()
        << " courses loaded from database." << endl;
}

//============================================================================
// Add Course
//============================================================================

void CourseCatalog::AddCourse() {

    Course course;

    cout << "Course ID: ";
    cin >> course.courseId;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "Title: ";
    getline(cin, course.title);

    int count;

    cout << "Number of prerequisites: ";
    cin >> count;

    for (int i = 0; i < count; i++) {

        string prereq;

        cout << "Prerequisite " << i + 1 << ": ";
        cin >> prereq;

        course.prerequisites.push_back(prereq);
    }

    courses[course.courseId] = course;

    SaveCoursesToDatabase();

    cout << "Course added successfully." << endl;
}

//============================================================================
// Update Course
//============================================================================

void CourseCatalog::UpdateCourse() {

    string courseId;

    cout << "Enter Course ID: ";
    cin >> courseId;

    if (courses.find(courseId) == courses.end()) {
        cout << "Course not found." << endl;
        return;
    }

    Course& course = courses[courseId];

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "New Title: ";
    getline(cin, course.title);

    course.prerequisites.clear();

    int count;

    cout << "Number of prerequisites: ";
    cin >> count;

    for (int i = 0; i < count; i++) {

        string prereq;

        cout << "Prerequisite " << i + 1 << ": ";
        cin >> prereq;

        course.prerequisites.push_back(prereq);
    }

    SaveCoursesToDatabase();

    cout << "Course updated." << endl;
}

//============================================================================
// Delete Course
//============================================================================

void CourseCatalog::DeleteCourse() {

    string courseId;

    cout << "Enter Course ID: ";
    cin >> courseId;

    if (courses.erase(courseId)) {
        SaveCoursesToDatabase();
        cout << "Course deleted." << endl;
    }
    else {
        cout << "Course not found." << endl;
    }
}

//============================================================================
// Print All Courses
//============================================================================

void CourseCatalog::PrintAllCourses() {

    vector<Course> sorted;

    for (auto& pair : courses) {
        sorted.push_back(pair.second);
    }

    sort(sorted.begin(), sorted.end(),
        [](const Course& a, const Course& b) {
            return a.courseId < b.courseId;
        });

    cout << "\nCourse List:\n";

    for (const Course& c : sorted) {
        cout << c.courseId << " - " << c.title << endl;
    }
}

//============================================================================
// Print Course Info
//============================================================================

void CourseCatalog::PrintCourseInfo(const string& courseId) {

    auto it = courses.find(courseId);

    if (it == courses.end()) {
        cout << "Course not found." << endl;
        return;
    }

    const Course& c = it->second;

    cout << "\n" << c.courseId << " - " << c.title << endl;

    cout << "Prerequisites: ";

    if (c.prerequisites.empty()) {
        cout << "None";
    }
    else {
        for (size_t i = 0; i < c.prerequisites.size(); i++) {
            cout << c.prerequisites[i];
            if (i < c.prerequisites.size() - 1)
                cout << ", ";
        }
    }

    cout << endl;
}

//============================================================================
// DFS Cycle Detection
//============================================================================

bool CourseCatalog::DetectCycle(
    const string& courseId,
    unordered_set<string>& visited,
    unordered_set<string>& stack) {

    if (stack.count(courseId)) return true;
    if (visited.count(courseId)) return false;

    visited.insert(courseId);
    stack.insert(courseId);

    for (const string& prereq : courses[courseId].prerequisites) {

        if (courses.find(prereq) == courses.end())
            continue;

        if (DetectCycle(prereq, visited, stack))
            return true;
    }

    stack.erase(courseId);
    return false;
}

//============================================================================
// Validate Prerequisites
//============================================================================

bool CourseCatalog::ValidatePrerequisites() {

    unordered_set<string> visited, stack;

    for (auto& pair : courses) {

        if (DetectCycle(pair.first, visited, stack)) {
            cout << "Cycle detected involving " << pair.first << endl;
            return false;
        }
    }

    cout << "No circular dependencies found." << endl;
    return true;
}

//============================================================================
// Course Path Display
//============================================================================

void CourseCatalog::DisplayPathRecursive(
    const string& courseId,
    int depth) {

    for (int i = 0; i < depth; i++)
        cout << "  ";

    cout << courseId << endl;

    for (const string& prereq : courses[courseId].prerequisites) {
        DisplayPathRecursive(prereq, depth + 1);
    }
}

void CourseCatalog::DisplayCoursePath(const string& courseId) {

    if (courses.find(courseId) == courses.end()) {
        cout << "Course not found." << endl;
        return;
    }

    cout << "\nPrerequisite Path:\n";
    DisplayPathRecursive(courseId, 0);
}

//============================================================================
// MAIN
//============================================================================

int main() {

    CourseCatalog catalog;

    string filename = "CS 300 ABCU_Advising_Program_Input.csv";

    int choice;

    while (true) {

        cout << "\nMenu:\n"
            << "1. Load CSV\n"
            << "2. Save to DB\n"
            << "3. Load from DB\n"
            << "4. Print Courses\n"
            << "5. Course Info\n"
            << "6. Add Course\n"
            << "7. Update Course\n"
            << "8. Delete Course\n"
            << "9. Validate\n"
            << "10. Course Path\n"
            << "0. Exit\n"
            << "Choice: ";

        cin >> choice;

        switch (choice) {

        case 1: catalog.LoadCourses(filename); break;
        case 2: catalog.SaveCoursesToDatabase(); break;
        case 3: catalog.LoadCoursesFromDatabase(); break;
        case 4: catalog.PrintAllCourses(); break;

        case 5: {
            string id;
            cout << "Course ID: ";
            cin >> id;
            catalog.PrintCourseInfo(id);
            break;
        }

        case 6: catalog.AddCourse(); break;
        case 7: catalog.UpdateCourse(); break;
        case 8: catalog.DeleteCourse(); break;
        case 9: catalog.ValidatePrerequisites(); break;

        case 10: {
            string id;
            cout << "Course ID: ";
            cin >> id;
            catalog.DisplayCoursePath(id);
            break;
        }

        case 0:
            cout << "Goodbye!" << endl;
            return 0;

        default:
            cout << "Invalid choice." << endl;
        }
    }
}a